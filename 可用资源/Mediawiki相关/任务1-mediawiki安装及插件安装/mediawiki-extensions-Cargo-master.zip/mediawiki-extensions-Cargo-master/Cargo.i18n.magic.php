<?php
/**
 * @ingroup Cargo
 */

$magicWords = [];

/** English (English) */
$magicWords['en'] = [
	'cargo_declare' => [ 0, 'cargo_declare' ],
	'cargo_attach' => [ 0, 'cargo_attach' ],
	'cargo_store' => [ 0, 'cargo_store' ],
	'cargo_query' => [ 0, 'cargo_query' ],
	'cargo_compound_query' => [ 0, 'cargo_compound_query' ],
	'cargo_display_map' => [ 0, 'cargo_display_map' ],
	'recurring_event' => [ 0, 'recurring_event' ],
];
