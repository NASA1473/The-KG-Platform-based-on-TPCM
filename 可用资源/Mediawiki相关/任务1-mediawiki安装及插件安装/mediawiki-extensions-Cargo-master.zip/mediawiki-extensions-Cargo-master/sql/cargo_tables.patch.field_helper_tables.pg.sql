ALTER TABLE /*_*/cargo_tables
 ADD field_helper_tables TEXT NOT NULL;