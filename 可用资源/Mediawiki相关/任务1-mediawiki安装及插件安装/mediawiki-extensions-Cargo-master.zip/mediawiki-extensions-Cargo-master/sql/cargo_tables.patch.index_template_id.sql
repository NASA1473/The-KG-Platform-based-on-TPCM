ALTER TABLE /*_*/cargo_tables
DROP INDEX cargo_tables_template_id;